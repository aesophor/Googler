import a.b.C;

public class D
{
    public static void main(String[] args)
    {
        C.main(new String[] {});
    }
}
