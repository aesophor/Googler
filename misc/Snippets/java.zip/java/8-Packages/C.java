package a.b;

public class C
{
    public static void main(String[] args)
    {
        System.out.println("Called C.main()");
    }
}
