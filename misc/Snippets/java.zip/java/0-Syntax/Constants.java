public class Constants {
    private Constants() {
        // Restrict instantiation.
    }

    public static int constantOne = 5;
    public static double constantTwo = 8;
}
