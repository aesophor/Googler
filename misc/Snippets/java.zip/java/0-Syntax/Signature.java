public class Signature {
    public int  myMethod(int param) {}
    public char myMethod(int param) {}
}
