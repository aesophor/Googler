public class DuplicateSymbolException extends Exception {
    
    public DuplicateSymbolException() {
        super("Duplicate symbol found...");
    }
}
