public class TypeLiterals {
    public static void main(String... args) {
        Class<?> typeInt = int.class;
        System.out.println(typeInt.toString());
    }
}
