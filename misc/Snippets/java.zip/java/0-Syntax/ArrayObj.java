public class ArrayObj {
    
    public static void main(String[] args) {
        System.out.println(new String[15].getClass().getName());
    }
}
