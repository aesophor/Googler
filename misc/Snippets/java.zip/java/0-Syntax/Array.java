public class Array {
    
    public static void main(String[] args) {
        int[] arr = new int[5];
        System.out.println(arr.length);
    }
}
